/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 sonic sonic.png 
 * Time-stamp: Tuesday 04/05/2022, 01:36:01
 * 
 * Image Information
 * -----------------
 * sonic.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SONIC_H
#define SONIC_H

extern const unsigned short sonic[400];
#define SONIC_SIZE 800
#define SONIC_LENGTH 400
#define SONIC_WIDTH 20
#define SONIC_HEIGHT 20

#endif

