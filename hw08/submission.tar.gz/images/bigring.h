/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x30 bigring bigring.png 
 * Time-stamp: Tuesday 04/05/2022, 01:36:50
 * 
 * Image Information
 * -----------------
 * bigring.png 30@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BIGRING_H
#define BIGRING_H

extern const unsigned short bigring[900];
#define BIGRING_SIZE 1800
#define BIGRING_LENGTH 900
#define BIGRING_WIDTH 30
#define BIGRING_HEIGHT 30

#endif

