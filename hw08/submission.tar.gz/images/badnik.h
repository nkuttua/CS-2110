/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 badnik badnik.png 
 * Time-stamp: Tuesday 04/05/2022, 01:36:30
 * 
 * Image Information
 * -----------------
 * badnik.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BADNIK_H
#define BADNIK_H

extern const unsigned short badnik[400];
#define BADNIK_SIZE 800
#define BADNIK_LENGTH 400
#define BADNIK_WIDTH 20
#define BADNIK_HEIGHT 20

#endif

