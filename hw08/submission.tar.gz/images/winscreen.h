/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 winscreen winscreen.jpg 
 * Time-stamp: Tuesday 04/05/2022, 00:13:19
 * 
 * Image Information
 * -----------------
 * winscreen.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WINSCREEN_H
#define WINSCREEN_H

extern const unsigned short winscreen[38400];
#define WINSCREEN_SIZE 76800
#define WINSCREEN_LENGTH 38400
#define WINSCREEN_WIDTH 240
#define WINSCREEN_HEIGHT 160

#endif

